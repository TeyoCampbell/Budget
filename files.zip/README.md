# Budget App

A mobile-friendly personal budgeting PWA with income/expense tracking, category budgets, monthly charts, and savings goals.

## Deploy to GitHub Pages

### 1. Create a GitHub repo
- Go to github.com → New repository
- Name it `budget-app` (or anything you like)
- Set it to Public
- Click **Create repository**

### 2. Upload the files
Upload all 4 files to the repo root:
- `index.html`
- `manifest.json`
- `sw.js`
- `icon-192.png` *(optional — add your own app icon)*
- `icon-512.png` *(optional — add your own app icon)*

You can drag and drop them in the GitHub UI (click "Add file → Upload files").

### 3. Enable GitHub Pages
- Go to your repo → **Settings** → **Pages**
- Under "Source", select **Deploy from a branch**
- Choose **main** branch, **/ (root)** folder
- Click **Save**

After ~60 seconds, your app will be live at:
`https://YOUR_USERNAME.github.io/budget-app/`

### 4. Add to Home Screen
- Open the URL on your phone in **Safari** (iOS) or **Chrome** (Android)
- iOS: tap the Share button → "Add to Home Screen"
- Android: tap the menu (⋮) → "Add to Home Screen" (or wait for the install banner)

Your data is saved locally on your device via localStorage.

## App icons (optional)
Add a square PNG image named `icon-192.png` (192×192 px) and `icon-512.png` (512×512 px) to the repo for a proper home screen icon. Any square image works — you can make one at favicon.io.
